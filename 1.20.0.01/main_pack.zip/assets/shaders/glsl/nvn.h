#define MCPE_PLATFORM_NX

//#if __VERSION__ >= 300
#define MAT4 highp mat4
#define POS4 highp vec4
#define POS3 highp vec3
precision highp float;
//#endif